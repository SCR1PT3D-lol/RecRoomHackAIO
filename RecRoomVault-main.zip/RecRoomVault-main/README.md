I made this awhile back on my other account @rxxvnge (https://github.com/rxxvnge/RecRoom-Vault) and I decided to pop back in to the com and reupload some things/edit/fix. 
Feel free to contact me on discord @funeralized if you have any questions/want me to add something. 
:D
